#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>
#include "region.h"
#include "read_csv.h"
#include "population.h"
#include "menu.h"
#include "create_html.h"



int main() {
    char* p = "bd_petite.csv";
    char* g = "bd_grande.csv";
    //menu();

    struct Population* pop = readfile(p);
    bool young = false;
    bool old = false;
    char* father_name = NULL;
    char* mother_name =  NULL;
    char* father_lastname = NULL;
    char* mother_lastname = NULL;
    unsigned int region_births=0;
    char regionname[WORD_MAX_SIZE] = "";
    unsigned int date_births=0;
    char* most_births=NULL;
    char querydate[DATE_SIZE]="";
    struct Person* found = NULL;
    struct Person* mostbrosandsis = NULL;
    query(pop,regionname, found,querydate,most_births, old,young, father_name, mother_name, father_lastname, mother_lastname);  // Exporter toutes les requêtes en HTML
    generate_html(pop);
    info_tree(pop);
    createunknown_html(pop);
    deletePopulation(pop);

    return 0;
}


