#ifndef PROJETCIR1_GROUPE_5_MENU_H
#define PROJETCIR1_GROUPE_5_MENU_H

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>
#include "region.h"
#include "read_csv.h"
#include "population.h"
#define FILENAME_SIZE 100
#define DATE_SIZE 6

void menu();
void clearInputBuffer();

#endif

